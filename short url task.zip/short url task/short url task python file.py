from flask import Flask,render_template,request
import pyshorteners
from flask import redirect
from flask import url_for

app = Flask(__name__)


@app.route("/", methods = ['GET', 'POST'])
def home():
    return render_template("index.html")

@app.route("/convertlink", methods = ['GET'])
def convert_function():
    url = request.args["url_name"]
    s = pyshortners.Shortener()
    short_url = s.tinyurl.short(url)
    short_url = str(short_url)
    return "The Shortened URL is: {}".format(short_url)

if __name__ == "__main__":
    app.run(debug = True)
